# Dino Blaster: Maximum Rage

**Game in development.** A free, retro-style browser rail shooter set against a Miami sunset. Steer your shiny ship, dodge enemy fire, and let its twin shoulder cannons do the shooting. Build a combo and survive the bosses with your original seven-track soundtrack.

**[Play on GitHub Pages](https://coughingdev.github.io/Dino-Rex/)** · [View the repository](https://github.com/coughingdev/Dino-Rex)

This is the **September 25, 2026 power-up guessing update**. The online game will reflect it after the package files are uploaded to the repository.

## Play

1. Open the game in a modern browser. On iPhone, use Safari and rotate to **landscape**.
2. Tap **☄ START RAGE**, or press **Enter** on a keyboard. The tap also unlocks audio on iPhone.
3. Hold the blue **↑** button to rise or the yellow **↓** button to descend. On a keyboard, use **Up/Down Arrow** or **W/S**.
4. Your cannons fire automatically. Dodge projectiles, shoot enemies before they escape off the left edge, and keep your combo going.

You start with **two hearts** and have **four heart slots**. The first shot that hits an adorable glowing enemy gives **+1 heart**. Bumping into an adorable enemy also gives +1 heart if it has not already paid its reward. Each adorable enemy pays only once, even if it takes several hits to defeat.

Their projectiles and letting them escape still cost half a heart. Other enemy hits cost a full heart. Taking damage briefly protects you from further damage. When your hearts run out, tap **↻ RESTART** (or press **Enter**) for a new run.

## Extra hearts: guess your power!

If a heart reward exceeds your four slots, the action pauses and a hidden power-up is rolled. **Guess which power-up it is. Correct guess: you get it. Wrong guess: no new power-up!** Your current hearts and existing powers are kept either way.

The three cards shuffle each round. Their rarity and odds are visible; the hidden answer is revealed only after your choice. Tap a card or press **1 / 2 / 3** for its displayed position. Tap **BACK TO RAGE** or press **Enter** after the reveal. A choice cannot be changed or rerolled.

| Power | Rarity / roll chance | Effect |
| --- | --- | --- |
| ⚡ Speed | Common · 55% | +10% ship handling and travel per correct guess, capped at +40% for the run. Enemies arrive faster, and combat score earns extra route progress toward bosses. |
| ◉ Defense | Rare · 30% | A visible protective bubble for 30 seconds. Chain kills within 2.5 seconds of one another to add 1 second per linked kill, up to 15 extra seconds per activation. |
| ☄ BIG BLAST | Legendary · 15% | Adds two manually fired, wide, shiny black flaming rocks. A rock pierces enemies and defeats each ordinary enemy it hits in one shot. Each boss or miniboss takes a random 10–49% of its maximum health, once per rock. |

**Fire BIG BLAST** with the on-screen ☄ button or **B / Space**. Unused shots stay available during the run; winning it again adds two more. Boss damage is capped below half of maximum health per shot; a weakened boss can still be finished by one. A short cooldown prevents accidental double firing.

Defense protects against damage and preserves your combo. A new Defense reward refreshes it to at least 30 seconds and renews its combo-extension allowance. Power timers, enemies, firing, and route progression pause while you guess. All powers reset on a new run.

Overflow from adorable enemies, boss rewards, Bear, and poker uses the same system. A half-heart crossing the cap also earns a guess. Two hearts awarded while full earn two guesses. Poker guesses wait until you finish the hand and return to the stage.

## Bosses and route milestones

| Route progress | Event |
| --- | --- |
| 1,111 or higher | The Hawk arrives, even if a jump skips past 1,111. |
| 3,500 or higher, after the Hawk | Hear the 8-bit axe-sharpening warning. |
| 4,000 or higher, after the Hawk | Nick the Axe Thrower arrives. His attacks follow the beats of his boss track. |

Without Speed, route progress follows your score. With Speed, combat adds bonus route progress, so a boss can arrive before the score counter reaches its old threshold. The **BOSS ROUTE** indicator tracks that progress. Score values remain unchanged.

Defeating either boss awards one heart and six seconds of protection. Beat the Hawk without taking damage during that fight to refill all four hearts, with at least the normal one-heart reward. Any excess becomes a power-up guess. Ordinary enemies, tougher tanks, zigzaggers, and recurring minibosses fill the spaces between major encounters. Difficulty increases with time and score.

## Original soundtrack

| File | When it plays |
| --- | --- |
| `audio/01-title.mp3` | Title screen and game over |
| `audio/02-stage-one.mp3` | Regular play |
| `audio/03-hawk.mp3` | Hawk boss |
| `audio/04-poker.mp3` | Secret poker hand |
| `audio/05-axes.mp3` | Axe warning |
| `audio/06-nick.mp3` | Nick boss |
| `audio/07-clear.mp3` | Boss victory |

Keep the `audio/` folder beside `index.html`; the game loads these MP3 files by relative path. Music changes with the action. On iPhone, tap **START RAGE** to allow the browser to play sound.

<details>
<summary>Secret controls and rewards (spoilers)</summary>

- Quickly press **Up → Down → Up**, then hold **Up** at the top of the screen for the Beast Bear's one-heart bonus.
- Quickly press **Down → Up → Down**, then hold **Down** at the bottom to open the poker hand. The code gives one heart immediately. Win the hand for two more hearts; folding grants half a heart. Overflow becomes guesses after poker.
- Each secret can be used once per run. The sequence resets if you wait too long between presses.

</details>

## Run or publish this build

The game is static HTML, CSS, and JavaScript. There is no install or build step. For a local preview, serve this folder with `python3 -m http.server 8000` and open `http://localhost:8000/` on your computer.

To update the existing GitHub Pages game:

1. Download and unzip `Dino-Blaster-Maximum-Rage.zip`. In the iPhone Files app, tap the ZIP to extract it.
2. Open the extracted `Dino-Blaster-Maximum-Rage` folder.
3. Upload **the contents of that folder** to the root of the `main` branch of [`coughingdev/Dino-Rex`](https://github.com/coughingdev/Dino-Rex), replacing the matching files and preserving the `audio/` folder.
4. Keep `index.html` at the repository root, beside `sw.js` and `manifest.webmanifest`. Do not upload the ZIP itself as the game or put the entire outer folder inside the repository.
5. Commit the changes. Keep the existing GitHub Pages deployment pointed at `main` and `/ (root)`. After deployment, reload the play link above.

The package includes a new service-worker cache version so the update replaces the previous cached build. If an already-open Home Screen session still shows the old game, close it and reopen the game while online.

The included manifest, icons, and service worker support adding the game to an iPhone Home Screen from Safari's **Share → Add to Home Screen** menu.

## Validation

The game JavaScript passed 25 automated gameplay checks using a simulated DOM and real Canvas renderer: first-hit heart rewards, overflow, correct and incorrect guesses, rarity boundaries, speed limits and boss triggers, shield protection and combo extension, two-shot ammo, boss damage limits, poker rewards, and reset behavior. The bubble and flaming-rock sprites were rendered and inspected. A live browser/iPhone Safari playtest remains to be done; those automated checks do not validate browser layout or Safari audio playback.

const CACHE='dino-rail-blaster-maximum-rage-v2';
const CORE=['./','./index.html','./manifest.webmanifest','./icon-180.png','./icon-192.png','./icon-512.png'];
const AUDIO=['./audio/01-title.mp3','./audio/02-stage-one.mp3','./audio/03-hawk.mp3','./audio/04-poker.mp3','./audio/05-axes.mp3','./audio/06-nick.mp3','./audio/07-clear.mp3'];
self.addEventListener('install',event=>event.waitUntil(
  caches.open(CACHE).then(async cache=>{
    await cache.addAll(CORE);
    // Audio can be downloaded later on a slow connection without blocking install.
    await Promise.allSettled(AUDIO.map(url=>cache.add(url)));
    await self.skipWaiting();
  })
));
self.addEventListener('activate',event=>event.waitUntil(
  caches.keys().then(names=>Promise.all(names
    .filter(name=>name!==CACHE&&(name.startsWith('disco-rex-')||name.startsWith('dino-rail-blaster-')))
    .map(name=>caches.delete(name)))).then(()=>self.clients.claim())
));
self.addEventListener('fetch',event=>{
  if(event.request.method!=='GET')return;
  if(event.request.mode==='navigate'){
    event.respondWith(fetch(event.request).then(response=>{
      if(response.ok){const copy=response.clone();caches.open(CACHE).then(cache=>cache.put('./index.html',copy));}
      return response;
    }).catch(()=>caches.match('./index.html')));
    return;
  }
  event.respondWith(caches.match(event.request).then(cached=>cached||fetch(event.request).then(response=>{
    if(response.ok){const copy=response.clone();caches.open(CACHE).then(cache=>cache.put(event.request,copy));}
    return response;
  })));
});

# Dino Rail Blaster – Electric Hawk Victory Build

GitHub Pages package.

## Hawk boss update
- New original Electric Hawk boss music: `audio/hawk-boss-theme-v2.wav`
- Hawk still triggers at score 1111 or higher
- Defeating the Hawk grants +1 life immediately (maximum 4 lives)
- 6 seconds of invincibility starts on the exact boss-kill frame
- All Hawk projectiles are cleared immediately on victory
- Regular enemy spawning pauses for 4 seconds after the boss dies
- Same-frame boss-kill protection: a final Hawk projectile cannot kill you after your killing shot lands

## GitHub layout
Keep `index.html` at the repository root and the WAV inside the `audio` folder.

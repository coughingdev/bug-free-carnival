# 🦖 Dino Rail Blaster: RAGE MODE

A fast, arcade-style **16-bit-inspired on-rails browser shooter** built for quick play on phones and desktops.

Pilot a heavily armed chrome dino through a neon Miami-style battlefield, dodge incoming fire, build your combo, and survive as the **RAGE** multiplier keeps climbing.

> **Status:** Game in development. This repository contains the current playable RAGE MODE build.

## 🎮 How to Play

Your shoulder cannons fire automatically. Your job is to move, dodge, survive, and keep the combo alive.

### Mobile / Touch

- **Blue ▲ button** — move up
- **Yellow ▼ button** — move down
- **☄ START RAGE** — start the run
- **↻ RESTART** — restart after beginning a run

The game is designed for **landscape play** on mobile.

### Keyboard

- **Arrow Up** or **W** — move up
- **Arrow Down** or **S** — move down
- **Enter** — start when the game is not running

## 🔥 RAGE MODE

The longer you survive, the more intense the game becomes.

RAGE increases with time and score, affecting the pace of enemy attacks and turning each run into a progressively harder bullet-hell challenge.

The HUD tracks:

- **Score**
- **Lives**
- **RAGE multiplier**
- **Combo**

Taking damage resets your combo.

## 👾 Enemies

The current build includes several enemy behaviors:

- **Normal enemies** — standard attackers
- **Zig enemies** — move with a stronger wave pattern
- **Tank enemies** — tougher enemies with extra health and double-shot attacks
- **Mini-bosses** — high-health enemies that fire spreading volleys and appear during longer runs

Enemy speed, health, spawn pressure, and projectile intensity increase as the run continues.

## 💥 Scoring

Destroying enemies awards points and increases your combo.

Higher combos add bonus points to kills, so staying untouched is the fastest way to push your score higher.

Approximate base values in the current build:

| Enemy | Base Points |
| --- | ---: |
| Normal / Zig | 30 |
| Tank | 60 |
| Mini-boss | 250 |

Combo bonuses are added on top of those values.

## ❤️ Lives

Each run begins with **2 lives**.

You lose a life when:

- An enemy projectile hits you
- You collide with an enemy
- An enemy escapes past you

After taking damage, the player receives a brief period of invincibility.

## 🌴 Visual Style

The current stage uses a retro arcade look with:

- Neon Miami sunset colors
- Pixel-style graphics
- Scrolling stars
- City skyline silhouettes
- Perspective grid / roadway
- Screen shake and particle effects
- A chrome-style armed dinosaur player character

## 📱 iPhone / Mobile Play

For the best mobile experience:

1. Open the GitHub Pages version of the game in Safari.
2. Rotate the phone to **landscape**.
3. Use the large blue and yellow touch controls.
4. Optionally use Safari's **Share → Add to Home Screen** for quick access.

The repository also includes web-app icons and a manifest for continued mobile/PWA development.

## 🚀 Publish with GitHub Pages

This project is designed to run as a static site with no build step.

1. Open the repository on GitHub.
2. Go to **Settings → Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**.
4. Select the **main** branch.
5. Select **/ (root)**.
6. Save.

GitHub Pages can then serve the game directly from the repository.

## 📁 Project Files

```text
Dino-Rex/
├── index.html
├── README.md
├── manifest.webmanifest
├── sw.js
├── icon-180.png
├── icon-192.png
└── icon-512.png
```

### Main files

- **index.html** — game, controls, rendering, enemy logic, scoring, and gameplay
- **manifest.webmanifest** — web-app metadata and icons
- **sw.js** — service-worker cache file for future/offline web-app support
- **icon-*.png** — app icons for mobile/web use

## 🛠️ Technology

Dino Rail Blaster is intentionally lightweight.

- HTML5
- CSS
- JavaScript
- Canvas 2D
- Pointer/touch controls
- Keyboard controls
- No game engine
- No required external libraries
- No build process

## 🧪 Current Development Direction

The project is still evolving. The larger Dino Rail Blaster concept is being developed around arcade-style stages, unusual enemies, bosses, secrets, escalating difficulty, retro presentation, and mobile-first play.

This README describes the mechanics that are currently present in the repository. Future gameplay additions may change these details.

## 🦖 Dino Rail Blaster

Built as a free browser game with one goal: **make surviving one more run feel impossible to resist.**

**Start RAGE. Survive. Beat your score.**
